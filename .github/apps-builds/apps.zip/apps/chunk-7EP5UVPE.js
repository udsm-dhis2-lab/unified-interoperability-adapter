function g(o){let t=new Date(o),e=new Date,n=e.getFullYear()-t.getFullYear(),a=e.getMonth()-t.getMonth();return(a<0||a===0&&e.getDate()<t.getDate())&&n--,n.toString()}export{g as a};
